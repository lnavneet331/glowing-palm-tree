text_f = document.querySelector("#add-text");
btn = document.querySelector("#add-btn");
root = document.querySelector("#root");
btn.addEventListener("click", () => {
  text = text_f.value;
  if (text.length != 0) {
    form = new FormData();
    form.append("post", text.trim());
    fetch("/addcomment/", {
      method: "POST",
      body: form,
    })
      .then((res) => res.json())
      .then((res) => {
        if (res.status == 201) {
          add_html(
            res.listing_id,
            res.username,
            text.trim(),
            res.timestamp,
            `/u/${res.username}`
          );
          text_f.value = "";
        }
      });
  }
});

  div6 = make_div("like mt-3");
  img = document.createElement("img");
  img.setAttribute("class", "liked");
  img.setAttribute("data-id", id);
  img.setAttribute("id", `post-like-${id}`);
  img.setAttribute("data-is_liked", "no");
  img.setAttribute(
    "src",
    "https://img.icons8.com/wired/2x/thumb-up.png"
  );
  like_handeler(img);
  span5 = document.createElement("span");
  span5.setAttribute("id", `post-count-${id}`);
  span5.textContent = "0";
  div6.appendChild(img);
  div6.appendChild(span5);
  div5.appendChild(span2);
  div5.appendChild(span3);
  a1.appendChild(span1);
  div4.appendChild(a1);
  div3.appendChild(div4);
  div3.appendChild(div5);
  div2.appendChild(div3);
  div2.appendChild(span4);
  div2.appendChild(textarea);
  div2.appendChild(div6);
  div1.appendChild(div2);
  root.appendChild(div1);
}